<?php

echo "<section><nav>";
echo "<a href='createContent.php'>Create Record</a>"; echo "&nbsp;&nbsp;|&nbsp;&nbsp;";
echo "<a href='selectContentToModify.php'>Content Table</a>";
echo "</nav></section>";
echo "<br />";

?>